//
//  WeatherCollectionViewCell.swift
//  Weather
//
//  Created by spark-02 on 2024/02/09.
//

import UIKit

class WeatherCollectionVIewCell: UICollectionViewCell {
    
    @IBOutlet weak var weatherImageView: UIImageView!
    
}
